public class zuul_main {
    public static void main(String[] args){
        Game zuulGame = new Game();
        zuulGame.play();
    }
}
